import tkinter as tk
from modules.sos import trigger_sos

def main():
    root = tk.Tk()
    root.title("Women Safety App")

    sos_button = tk.Button(root, text="Trigger SOS", command=trigger_sos, bg="red", fg="white", font=("Arial", 18))
    sos_button.pack(pady=50)

    root.mainloop()

if __name__ == "__main__":
    main()
