import webbrowser
import time
import playsound
from geopy.geocoders import Nominatim

def get_location():
    geolocator = Nominatim(user_agent="women_safety_app")
    location = geolocator.geocode("Your City, India")  # Simulated location
    return location.address if location else "Location not found"

def trigger_sos():
    print("🚨 SOS Triggered!")
    location = get_location()
    print("Location:", location)

    playsound.playsound("assets/siren.mp3")
    webbrowser.open("mailto:emergency@example.com?subject=Help&body=I'm in danger. My location is: " + location)
