# Women Safety App (Python Version)

This is a desktop-based Women Safety Application built with Python. It features a one-tap SOS alert system with:

- 🚨 Siren sound
- 📍 Location tracking (simulated)
- 📧 Emergency email alert

## Requirements

- Python 3.x
- `geopy`
- `playsound`

## How to Run

1. Install dependencies:
   ```bash
   pip install geopy playsound
   ```

2. Place a siren MP3 file in the `assets/` folder as `siren.mp3`.

3. Run the app:
   ```bash
   python src/main.py
   ```
